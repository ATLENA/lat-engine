#!/bin/sh

## Business System Base Environment (modify them)
#export JAVA_HOME=/usr/bin/java
export LAT_HOME=/apps/lat/1.0.0
export INSTANCE_ID=lat
export INSTALL_PATH=/apps/lat/1.0.0/instances/lat-was-8080
export LOG_HOME=/apps/lat/1.0.0/instances/lat-was-8080/logs
export ERROR_LOG_PATH=${LOG_HOME}/error.log

## Catalina Environment (don't modify them)
export ENGN_VERSION=1.23.1
export ENGN_HOME=${LAT_HOME}/engines/runtime/nginx/${ENGN_VERSION}
export TEMPLATE_VERSION=1.23.1

export RUN_USER=lat
export INST_NAME=${INSTANCE_ID}_`hostname`

export NGINX_PID=${CATALINA_BASE}/${INSTANCE_ID}.pid

