#!/bin/sh

## Business System Base Environment (modify them)
export LAT_HOME=/apps/lat/1.0.0
export INSTANCE_ID=lat-redis-6379
export SERVICE_PORT=6379
export INSTALL_PATH=/apps/lat/1.0.0/instances/lat-redis-6379
export RUN_USER=lat
export DATE=`date +%Y%m%d-%H%M%S`

export LOG_HOME=${INSTALL_PATH}/logs
export PID=${CATALINA_BASE}/${INST_NAME}.pid
export ENGN_VERSION=7.0.12
export ENGN_HOME=${LAT_HOME}/engines/runtime/redis/${ENGN_VERSION}
export TEMPLATE_VERSION=7.0.12
export REDIS_TYPE=MASTER
